# CosteCoche

React + Vite + Tailwind (tokens exportados de Stitch) + lucide-react. Sin backend.

    npm install
    npm run dev       # desarrollo
    npm run build     # producción en /dist

## Antes de publicar
1. Sustituye `costecoche.es` por tu dominio en `public/sitemap.xml`, `public/robots.txt` y `.env` (`VITE_SITE_URL`).
2. Cambia `CONTACT_EMAIL` en `src/data/site.js` y completa titular/NIF en `TextPage.jsx` (privacidad).
3. AdSense: pon `VITE_ADSENSE_CLIENT` y, opcionalmente, `VITE_ADSENSE_SLOT_HOME` / `VITE_ADSENSE_SLOT_CALC`. Los anuncios solo cargan tras aceptar cookies. Añade `ads.txt` en `public/`.
4. Despliegue: `vercel.json` y `public/_redirects` (Netlify) ya reescriben rutas al SPA.

## Añadir una calculadora
Añade un objeto en `src/data/calculators.js` (campos, `compute`, SEO, FAQs). La ruta, la tarjeta de inicio, el listado, el pie y el sitemap (añade la URL a mano) se alimentan de ahí.

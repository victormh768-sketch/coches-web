import { Routes, Route, Link } from 'react-router-dom'
import Layout from './components/Layout'
import Seo from './components/Seo'
import Home from './pages/Home'
import Calculadoras from './pages/Calculadoras'
import CalcPage from './components/CalcPage'
import { About, HowPage, Contact, Privacy, Cookies, Terms } from './pages/TextPage'
import { ALL } from './data/calculators'

const NotFound = () => (
  <section className="py-24 text-center px-margin">
    <Seo title="Página no encontrada | CosteCoche" description="La página que buscas no existe." noindex />
    <h1 className="font-display-hero-mobile text-display-hero-mobile font-extrabold">404</h1>
    <p className="font-body-lg text-on-surface-variant mt-space-md">No encontramos esa página.</p>
    <Link to="/" className="inline-flex mt-space-lg px-space-lg py-2.5 rounded-lg bg-tertiary-container text-on-tertiary font-semibold">Volver al inicio</Link>
  </section>
)

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="/calculadoras" element={<Calculadoras />} />
        {ALL.map((c) => <Route key={c.path} path={c.path} element={<CalcPage c={c} />} />)}
        <Route path="/como-funciona" element={<HowPage />} />
        <Route path="/sobre-nosotros" element={<About />} />
        <Route path="/contacto" element={<Contact />} />
        <Route path="/politica-privacidad" element={<Privacy />} />
        <Route path="/politica-cookies" element={<Cookies />} />
        <Route path="/terminos" element={<Terms />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}

import { useState } from 'react'
import Icon from './Icon'
import { CalcCard, NumInput, ResultPanel, StickyTotal } from './ui'
import { eur, num, val } from '../lib/format'

const PRESETS = {
  gasolina: { icon: 'Fuel', name: 'Gasolina', c: 6.5, p: 1.62, uc: 'l/100km', up: '€/l', lc: 'Consumo medio (l/100km)', lp: 'Precio combustible (€/litro)' },
  diesel: { icon: 'Droplet', name: 'Diésel', c: 5.4, p: 1.54, uc: 'l/100km', up: '€/l', lc: 'Consumo medio (l/100km)', lp: 'Precio diésel (€/litro)' },
  hibrido: { icon: 'Leaf', name: 'Híbrido', c: 4.6, p: 1.62, uc: 'l/100km', up: '€/l', lc: 'Consumo medio combinado', lp: 'Precio gasolina (€/litro)' },
  electrico: { icon: 'Zap', name: 'Eléctrico', c: 17.5, p: 0.18, uc: 'kWh/100km', up: '€/kWh', lc: 'Consumo eléctrico (kWh/100km)', lp: 'Precio de recarga (€/kWh)' },
}

export default function MainCalculator({ id = 'calculadora-principal' }) {
  const [fuel, setFuel] = useState('gasolina')
  const [s, setS] = useState({ km: 1250, c: 6.5, p: 1.62, seg: 480, mant: 350, imp: 140, otros: 250 })
  const set = (k) => (v) => setS((o) => ({ ...o, [k]: v }))
  const P = PRESETS[fuel]
  const pick = (f) => { setFuel(f); setS((o) => ({ ...o, c: PRESETS[f].c, p: PRESETS[f].p })) }

  const km = val(s.km), comb = km * (val(s.c) / 100) * val(s.p) * 12
  const fijos = val(s.seg) + val(s.mant) + val(s.imp) + val(s.otros)
  const ano = comb + fijos, mes = ano / 12, kmAno = km * 12
  const headline = { label: 'Tu coche te cuesta aproximadamente', value: num(mes), unit: '€ / mes', sub: 'Suma consolidada de energía, seguros, tasas y mantenimiento.' }
  const fixedIn = [['seg', 'Seguro anual', 10], ['mant', 'Mantenimiento', 10], ['imp', 'Impuestos (IVTM)', 5], ['otros', 'Otros (ITV/park)', 10]]

  return (
    <CalcCard icon="BarChart3" title="Calcula el coste de tu coche" desc="Ajusta los parámetros para obtener el desglose mensual, anual y por kilómetro en tiempo real.">
      <div className="lg:col-span-7 flex flex-col gap-space-lg">
        <div className="flex flex-col gap-space-xs">
          <span id={id + '-prop'} className="font-headline-sm text-headline-sm text-on-surface font-semibold">Tipo de propulsión</span>
          <div role="group" aria-labelledby={id + '-prop'} className="grid grid-cols-2 sm:grid-cols-4 gap-space-xs p-1 rounded-xl bg-surface-container-low">
            {Object.entries(PRESETS).map(([k, x]) => (
              <button key={k} type="button" aria-pressed={fuel === k} onClick={() => pick(k)}
                className={'flex items-center justify-center gap-space-xs py-2.5 px-space-sm rounded-lg font-body-md text-body-md font-semibold transition-all ' + (fuel === k ? 'bg-surface-container-lowest text-on-surface shadow-sm' : 'text-on-surface-variant hover:text-on-surface')}>
                <Icon name={x.icon} size={18} /><span>{x.name}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="p-space-md rounded-xl bg-surface-container-low flex flex-col gap-space-sm">
          <div className="flex items-center justify-between gap-2">
            <label htmlFor={id + '-km'} className="font-body-md text-body-md font-semibold text-on-surface flex items-center gap-space-xs"><Icon name="Gauge" size={18} className="text-on-surface-variant" />Kilómetros al mes</label>
            <div className="flex items-center gap-1">
              <input id={id + '-km'} type="number" inputMode="numeric" min="0" step="50" value={s.km} onChange={(e) => set('km')(e.target.value)} className="tnum w-20 text-right bg-surface-container-lowest rounded-md px-2 py-1 font-label-numeric text-label-numeric shadow-inner focus:outline-none focus:ring-2 focus:ring-secondary" />
              <span className="font-body-sm text-body-sm text-on-surface-variant">km/mes</span>
            </div>
          </div>
          <input aria-label="Kilómetros al mes" type="range" min="100" max="5000" step="50" value={Math.min(5000, Math.max(100, val(s.km)))} onChange={(e) => set('km')(e.target.value)} className="w-full accent-secondary cursor-pointer h-2 bg-surface-container rounded-lg" />
          <div className="flex justify-between font-body-sm text-body-sm text-on-surface-variant gap-2"><span>300 km (Urbano bajo)</span><span className="hidden sm:inline">1.250 km (Media España)</span><span>3.000+ km (Viajero)</span></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
          <NumInput id={id + '-c'} label={P.lc} unit={P.uc} step={0.1} value={s.c} onChange={set('c')} />
          <NumInput id={id + '-p'} label={P.lp} unit={P.up} step={0.01} value={s.p} onChange={set('p')} />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-space-sm pt-space-xs">
          {fixedIn.map(([k, l, st]) => (
            <div key={k} className="flex flex-col gap-1 p-space-sm rounded-lg bg-surface-container-low">
              <label htmlFor={id + k} className="font-body-sm text-body-sm font-semibold text-on-surface truncate">{l}</label>
              <div className="flex items-center"><span className="text-on-surface-variant font-label-numeric text-label-numeric mr-1">€</span>
                <input id={id + k} type="number" inputMode="decimal" min="0" step={st} value={s[k]} onChange={(e) => set(k)(e.target.value)} className="tnum w-full bg-surface-container-lowest rounded px-2 py-1 font-label-numeric text-label-numeric text-on-surface focus:outline-none focus:ring-2 focus:ring-secondary" /></div>
            </div>
          ))}
        </div>
        <button type="button" onClick={() => document.getElementById(id + '-res')?.scrollIntoView({ behavior: 'smooth', block: 'center' })}
          className="inline-flex items-center justify-center gap-space-xs w-full py-3.5 rounded-lg bg-secondary text-on-secondary font-headline-sm text-headline-sm font-semibold shadow hover:opacity-95 active:scale-95 transition-all">
          <Icon name="RefreshCw" size={20} />Calcular coste actualizado
        </button>
      </div>
      <ResultPanel id={id + '-res'} headline={headline} badge={eur(ano) + ' / año'}
        cards={[['Por km', eur(kmAno ? ano / kmAno : 0, 2)], ['Al año', eur(ano)], ['En 5 años', eur(ano * 5)]]}
        breakdown={[['Combustible', comb], ['Seguro', val(s.seg)], ['Taller', val(s.mant)], ['Impuestos y otros', val(s.imp) + val(s.otros)]]}
        note="No incluye la cuota de compra ni la depreciación." />
      <StickyTotal headline={headline} />
    </CalcCard>
  )
}

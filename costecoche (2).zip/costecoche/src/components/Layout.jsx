import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import Icon from './Icon'
import { CookieBanner } from './Consent'
import { CALCULATORS, MAIN } from '../data/calculators'

const NAV = [['/', 'Inicio'], ['/calculadoras', 'Calculadoras'], ['/como-funciona', 'Cómo funciona'], ['/sobre-nosotros', 'Sobre nosotros']]
const linkCls = ({ isActive }) => 'transition-colors font-body-md text-body-md ' + (isActive ? 'text-on-surface font-semibold' : 'text-on-surface-variant hover:text-on-surface')

function Logo({ h = 'h-8' }) {
  return (
    <span className="flex items-center gap-space-sm">
      <span className={h + ' aspect-square rounded-lg bg-primary-container flex items-center justify-center'}><Icon name="CarFront" size={18} className="text-on-primary" /></span>
      <span className="font-headline-sm text-headline-sm text-on-surface tracking-tight font-bold">CosteCoche</span>
    </span>
  )
}

export function Header() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  useEffect(() => setOpen(false), [pathname])
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-surface-container-lowest/90 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
      <div className="h-16 max-w-[1200px] mx-auto px-margin flex items-center justify-between gap-gutter">
        <Link to="/" aria-label="CosteCoche, inicio"><Logo /></Link>
        <nav aria-label="Principal" className="hidden md:flex items-center gap-space-lg">
          {NAV.map(([to, t]) => <NavLink key={to} to={to} end={to === '/'} className={linkCls}>{t}</NavLink>)}
        </nav>
        <div className="flex items-center gap-space-md">
          <Link to={MAIN.path} className="hidden sm:inline-flex items-center justify-center px-space-md py-space-sm rounded-lg bg-tertiary-container text-on-tertiary font-body-md text-body-md font-semibold transition-all hover:bg-on-tertiary-fixed-variant shadow-[0_1px_2px_rgba(15,23,42,0.04)]">Calcular coste</Link>
          <button type="button" className="md:hidden w-9 h-9 rounded-full bg-primary flex items-center justify-center" aria-expanded={open} aria-label="Menú" onClick={() => setOpen(!open)}><Icon name={open ? 'X' : 'Menu'} size={18} className="text-on-primary" /></button>
        </div>
      </div>
      {open && (
        <nav aria-label="Móvil" className="md:hidden bg-surface-container-lowest border-t border-surface-container px-margin py-space-md flex flex-col gap-space-md">
          {NAV.map(([to, t]) => <NavLink key={to} to={to} end={to === '/'} className={linkCls}>{t}</NavLink>)}
          <Link to={MAIN.path} className="inline-flex justify-center px-space-md py-space-sm rounded-lg bg-tertiary-container text-on-tertiary font-body-md text-body-md font-semibold">Calcular coste</Link>
        </nav>
      )}
    </header>
  )
}

const FL = 'hover:text-on-surface transition-colors'
export function Footer() {
  return (
    <footer className="w-full bg-surface-container-low mt-space-xl">
      <div className="max-w-[1200px] mx-auto px-margin pt-space-xl pb-space-lg">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-gutter pb-space-xl">
          <div className="lg:col-span-2 flex flex-col items-start pr-0 lg:pr-space-lg">
            <div className="mb-space-md"><Logo h="h-7" /></div>
            <p className="font-body-md text-body-md text-on-surface-variant max-w-sm mb-space-lg">Herramientas y calculadoras transparentes y gratuitas para entender el coste total de propiedad de tu vehículo.</p>
            <div className="inline-flex items-center gap-space-xs px-space-sm py-space-xs rounded-full bg-secondary-container text-on-secondary-container font-label-badge text-label-badge uppercase tracking-wider"><Icon name="BadgeCheck" size={14} />Sin registro necesario</div>
          </div>
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold mb-space-xs">Calculadoras</h3>
            <ul className="flex flex-col gap-space-xs font-body-sm text-body-sm text-on-surface-variant">
              <li><Link className={FL} to={MAIN.path}>Coste del coche</Link></li>
              {CALCULATORS.map((c) => <li key={c.path}><Link className={FL} to={c.path}>{c.title}</Link></li>)}
            </ul>
          </div>
          <div className="flex flex-col gap-space-sm">
            <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold mb-space-xs">Plataforma</h3>
            <ul className="flex flex-col gap-space-xs font-body-sm text-body-sm text-on-surface-variant">
              {[['/', 'Inicio'], ['/como-funciona', 'Cómo funciona'], ['/sobre-nosotros', 'Sobre nosotros'], ['/contacto', 'Contacto']].map(([to, t]) => <li key={to}><Link className={FL} to={to}>{t}</Link></li>)}
            </ul>
          </div>
        </div>
        <div className="pt-space-lg flex flex-col md:flex-row items-center justify-between gap-space-md font-body-sm text-body-sm text-on-surface-variant">
          <p>© {new Date().getFullYear()} CosteCoche. Herramientas 100% gratuitas e independientes.</p>
          <div className="flex flex-wrap items-center justify-center gap-space-md">
            <Link className={FL} to="/terminos">Términos</Link><span>·</span>
            <Link className={FL} to="/politica-privacidad">Política de privacidad</Link><span>·</span>
            <Link className={FL} to="/politica-cookies">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default function Layout() {
  const { pathname, hash } = useLocation()
  useEffect(() => { if (!hash) window.scrollTo(0, 0); else document.getElementById(hash.slice(1))?.scrollIntoView() }, [pathname, hash])
  return (
    <>
      <a href="#contenido" className="sr-only focus:not-sr-only fixed top-2 left-2 z-[70] bg-surface-container-lowest px-3 py-2 rounded-lg">Saltar al contenido</a>
      <Header />
      <main id="contenido" className="w-full pt-16 bg-background min-h-screen"><Outlet /></main>
      <Footer />
      <CookieBanner />
    </>
  )
}

import { useState } from 'react'
import { Link } from 'react-router-dom'
import Seo, { faqLd, crumbLd } from './Seo'
import { CalcCard, NumInput, ResultPanel, StickyTotal, FaqList, ToolCard } from './ui'
import { AdSlot } from './Consent'
import Icon from './Icon'
import MainCalculator from './MainCalculator'
import { ALL, MAIN } from '../data/calculators'
import { SITE } from '../data/site'

function Form({ c }) {
  const init = {}; c.sections.forEach((s) => s.fields.forEach((f) => (init[f.id] = f.def)))
  const [v, setV] = useState(init)
  const r = c.compute(v)
  return (
    <CalcCard icon={c.icon} title={c.h1.replace(/^Calculadora de /, 'Calcula: ').replace(/^Comparador de costes: /, 'Compara: ')} desc="Ajusta los parámetros y obtén el resultado en tiempo real.">
      <div className="lg:col-span-7 flex flex-col gap-space-lg">
        {c.sections.map((s, i) => (
          <div key={i} className="flex flex-col gap-space-md">
            {s.title && <h3 className="font-headline-sm text-headline-sm text-on-surface font-semibold">{s.title}</h3>}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-md">
              {s.fields.map((f) => <NumInput key={f.id} id={c.path.slice(1) + '-' + f.id} label={f.label} unit={f.unit} step={f.step} value={v[f.id]} onChange={(x) => setV((o) => ({ ...o, [f.id]: x }))} />)}
            </div>
          </div>
        ))}
      </div>
      <ResultPanel kicker="Resultado" headline={r.headline} badge={r.badge} cards={r.cards} breakdown={r.breakdown.map(([l, x]) => [l, x])} note={r.note} />
      <StickyTotal headline={r.headline} />
    </CalcCard>
  )
}

export default function CalcPage({ c }) {
  const isMain = c === MAIN
  const others = ALL.filter((x) => x !== c).slice(0, 3)
  return (
    <>
      <Seo title={c.seo.title} description={c.seo.description} jsonLd={[
        faqLd(c.faqs), crumbLd([['Inicio', '/'], ['Calculadoras', '/calculadoras'], [c.title, c.path]]),
        { '@context': 'https://schema.org', '@type': 'WebApplication', name: c.h1, url: SITE + c.path, applicationCategory: 'FinanceApplication', operatingSystem: 'Any', inLanguage: 'es', offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' } },
      ]} />
      <section className="relative w-full bg-surface pt-space-xl pb-space-lg">
        <div className="max-w-[1200px] mx-auto px-margin">
          <nav aria-label="Migas de pan" className="flex items-center gap-1 font-body-sm text-body-sm text-on-surface-variant mb-space-md">
            <Link to="/" className="hover:text-on-surface">Inicio</Link><Icon name="ChevronRight" size={14} /><Link to="/calculadoras" className="hover:text-on-surface">Calculadoras</Link><Icon name="ChevronRight" size={14} /><span className="text-on-surface font-semibold">{c.title}</span>
          </nav>
          <h1 className="font-display-hero-mobile md:font-display-hero text-display-hero-mobile md:text-display-hero text-on-surface font-extrabold tracking-tight mb-space-md max-w-3xl">{c.h1}</h1>
          <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl">{c.intro || 'Calcula en segundos cuánto gastas en combustible, seguro, mantenimiento, impuestos y costes ocultos.'}</p>
        </div>
      </section>
      <section className="w-full py-space-xl bg-surface-container-low pb-24 lg:pb-space-xl">
        <div className="max-w-[1200px] mx-auto px-margin">{isMain ? <MainCalculator id="calc" /> : <Form key={c.path} c={c} />}</div>
        <div className="max-w-[1200px] mx-auto px-margin mt-space-lg"><AdSlot slot={import.meta.env.VITE_ADSENSE_SLOT_CALC} /></div>
      </section>
      <section className="w-full py-space-xl lg:py-24 bg-surface">
        <div className="max-w-[880px] mx-auto px-margin">
          <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold mb-space-lg text-center">Preguntas frecuentes</h2>
          <FaqList faqs={c.faqs} />
        </div>
      </section>
      <section className="w-full py-space-xl bg-surface-container-low">
        <div className="max-w-[1200px] mx-auto px-margin">
          <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold mb-space-lg">Otras calculadoras</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">{others.map((x) => <ToolCard key={x.path} c={x} />)}</div>
        </div>
      </section>
    </>
  )
}

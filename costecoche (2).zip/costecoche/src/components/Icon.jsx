import * as L from 'lucide-react'
export default function Icon({ name, size = 20, className = '', ...p }) {
  const C = L[name] || L.Circle
  return <C size={size} className={className} aria-hidden="true" {...p} />
}

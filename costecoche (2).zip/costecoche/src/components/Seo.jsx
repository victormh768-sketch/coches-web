import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { SITE, NAME } from '../data/site'

function meta(sel, attr, key, content) {
  let el = document.head.querySelector(sel)
  if (!el) { el = document.createElement('meta'); el.setAttribute(attr, key); document.head.appendChild(el) }
  el.setAttribute('content', content)
}
export default function Seo({ title, description, jsonLd, noindex }) {
  const { pathname } = useLocation()
  useEffect(() => {
    const url = SITE + (pathname === '/' ? '' : pathname)
    document.title = title
    meta('meta[name="description"]', 'name', 'description', description)
    meta('meta[name="robots"]', 'name', 'robots', noindex ? 'noindex,follow' : 'index,follow')
    meta('meta[property="og:title"]', 'property', 'og:title', title)
    meta('meta[property="og:description"]', 'property', 'og:description', description)
    meta('meta[property="og:url"]', 'property', 'og:url', url)
    meta('meta[property="og:type"]', 'property', 'og:type', 'website')
    meta('meta[property="og:site_name"]', 'property', 'og:site_name', NAME)
    let link = document.head.querySelector('link[rel="canonical"]')
    if (!link) { link = document.createElement('link'); link.rel = 'canonical'; document.head.appendChild(link) }
    link.href = url
    document.head.querySelectorAll('script[data-seo]').forEach((s) => s.remove())
    ;(jsonLd || []).forEach((d) => {
      const s = document.createElement('script'); s.type = 'application/ld+json'; s.dataset.seo = '1'
      s.text = JSON.stringify(d); document.head.appendChild(s)
    })
  }, [title, description, pathname, noindex, JSON.stringify(jsonLd)])
  return null
}
export const faqLd = (faqs) => ({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) })
export const crumbLd = (items) => ({ '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: items.map(([name, path], i) => ({ '@type': 'ListItem', position: i + 1, name, item: SITE + path })) })

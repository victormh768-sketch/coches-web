import { Link } from 'react-router-dom'
import Icon from './Icon'

export function NumInput({ id, label, value, onChange, unit, step = 1, className = '' }) {
  return (
    <div className={'flex flex-col gap-space-xs ' + className}>
      <label htmlFor={id} className="font-body-md text-body-md font-semibold text-on-surface">{label}</label>
      <div className="relative">
        <input id={id} type="number" inputMode="decimal" min="0" step={step} value={value} onChange={(e) => onChange(e.target.value)}
          className="tnum w-full bg-surface-container-low rounded-lg pl-space-md pr-14 py-2.5 font-label-numeric text-label-numeric text-on-surface focus:outline-none focus:ring-2 focus:ring-secondary" />
        {unit && <span className="absolute right-3 top-2.5 font-body-sm text-body-sm text-on-surface-variant pointer-events-none">{unit}</span>}
      </div>
    </div>
  )
}

const BAR = ['bg-secondary', 'bg-on-tertiary-container', 'bg-surface-tint', 'bg-outline-variant']
export function ResultPanel({ kicker = 'Coste total recurrente', headline, badge, cards, breakdown, note, id }) {
  const tot = breakdown.reduce((a, [, v]) => a + v, 0)
  let acc = 0
  const pcts = breakdown.map(([, v], i) => { const p = i === breakdown.length - 1 ? Math.max(0, 100 - acc) : tot > 0 ? Math.round((v / tot) * 100) : 0; acc += p; return p })
  const top = pcts.indexOf(Math.max(...pcts))
  return (
    <div id={id} aria-live="polite" className="lg:col-span-5 flex flex-col justify-between p-space-md lg:p-space-xl rounded-2xl bg-surface-container text-on-surface shadow-md scroll-mt-20">
      <div>
        <div className="flex items-center justify-between mb-space-sm gap-2">
          <span className="font-label-badge text-label-badge uppercase tracking-wider text-on-surface-variant">{kicker}</span>
          <span className="tnum px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container font-label-badge text-label-badge font-bold text-right">{badge}</span>
        </div>
        <p className="font-body-md text-body-md text-on-surface-variant">{headline.label}:</p>
        <div className="my-space-md">
          <div className="flex items-baseline gap-space-xs flex-wrap">
            <span className="tnum font-headline-metric-mobile md:font-headline-metric text-headline-metric-mobile md:text-headline-metric text-on-surface font-extrabold tracking-tight">{headline.value}</span>
            <span className="font-headline-md text-headline-md text-on-surface font-semibold">{headline.unit}</span>
          </div>
          <p className="font-body-sm text-body-sm text-on-surface-variant mt-1">{headline.sub}</p>
        </div>
        <div className="grid grid-cols-3 gap-space-xs my-space-lg">
          {cards.map(([l, v], i) => (
            <div key={l} className="p-space-sm rounded-xl bg-surface-container-lowest text-center shadow-sm">
              <p className="font-body-sm text-body-sm text-on-surface-variant">{l}</p>
              <p className={'tnum font-headline-sm text-headline-sm font-bold mt-1 break-words ' + (i === 0 ? 'text-secondary' : 'text-on-surface')}>{v}</p>
            </div>
          ))}
        </div>
        <div className="my-space-md">
          <div className="flex justify-between items-center font-body-sm text-body-sm text-on-surface mb-2 gap-2">
            <span className="font-semibold">Distribución del gasto</span>
            <span className="text-secondary font-bold tnum">{pcts[top]}% {breakdown[top][0]}</span>
          </div>
          <div className="w-full h-3 rounded-full bg-surface-container-high overflow-hidden flex shadow-inner" role="img" aria-label="Distribución porcentual del gasto">
            {pcts.map((p, i) => <div key={i} className={'h-full transition-all duration-500 ' + BAR[i]} style={{ width: p + '%' }} />)}
          </div>
          <div className="grid grid-cols-2 gap-space-xs font-body-sm text-body-sm mt-space-sm text-on-surface-variant">
            {breakdown.map(([l], i) => <div key={l} className="flex items-center gap-1.5"><span className={'w-2.5 h-2.5 rounded-sm shrink-0 ' + BAR[i]} /><span>{l} (<span className="tnum">{pcts[i]}%</span>)</span></div>)}
          </div>
        </div>
      </div>
      <div className="pt-space-md mt-space-md flex flex-col gap-space-xs">
        <p className="font-body-sm text-body-sm text-on-surface-variant flex items-start gap-1.5"><Icon name="Info" size={16} className="text-secondary shrink-0 mt-0.5" /><span>{note} Es una estimación orientativa.</span></p>
        <Link to="/calculadoras" className="inline-flex items-center gap-1 font-body-sm text-body-sm font-semibold text-secondary hover:underline self-start">Ver todas las calculadoras <Icon name="ArrowRight" size={16} /></Link>
      </div>
    </div>
  )
}

export function StickyTotal({ headline }) {
  return (
    <div className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-surface-container-lowest border-t border-outline-variant shadow-[0_-4px_12px_rgba(15,23,42,0.06)] px-margin py-3 flex items-baseline justify-between">
      <span className="font-body-sm text-body-sm text-on-surface-variant">{headline.label}</span>
      <span className="tnum font-headline-sm text-headline-sm font-bold text-on-surface">{headline.value} <span className="font-body-sm text-body-sm font-normal text-on-surface-variant">{headline.unit}</span></span>
    </div>
  )
}

export function CalcCard({ icon, eyebrow = 'Simulador Instantáneo', title, desc, children }) {
  return (
    <div className="bg-surface-container-lowest rounded-2xl shadow-xl overflow-hidden">
      <div className="px-space-md lg:px-space-xl pt-space-lg lg:pt-space-xl pb-space-lg bg-gradient-to-r from-surface-container-lowest via-surface-container-lowest to-surface-container-low flex flex-col md:flex-row md:items-center justify-between gap-space-md">
        <div>
          <div className="flex items-center gap-space-xs mb-1">
            <span className="inline-flex p-1.5 rounded-lg bg-secondary-container text-on-secondary-container"><Icon name={icon} size={20} /></span>
            <span className="font-label-badge text-label-badge text-secondary font-semibold uppercase tracking-wider">{eyebrow}</span>
          </div>
          <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold">{title}</h2>
          <p className="font-body-md text-body-md text-on-surface-variant">{desc}</p>
        </div>
        <div className="inline-flex items-center gap-space-xs self-start md:self-auto px-space-md py-1.5 rounded-full bg-surface-container text-on-surface-variant font-label-numeric text-label-numeric"><span className="w-2 h-2 rounded-full bg-secondary" /><span>Cálculo dinámico automático</span></div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter p-space-md lg:p-space-xl">{children}</div>
    </div>
  )
}

export function ToolCard({ c }) {
  return (
    <Link to={c.path} className="group relative flex flex-col justify-between p-space-lg rounded-2xl bg-surface-container-lowest shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div>
        <div className="w-12 h-12 rounded-xl bg-surface-container-low flex items-center justify-center text-on-surface mb-space-md group-hover:bg-secondary group-hover:text-on-secondary transition-colors"><Icon name={c.icon} size={26} /></div>
        <h3 className="font-headline-sm text-headline-sm font-semibold text-on-surface mb-1">{c.title}</h3>
        <p className="font-body-md text-body-md text-on-surface-variant">{c.cardDesc}</p>
      </div>
      <span className="pt-space-lg mt-space-md inline-flex items-center gap-space-xs font-headline-sm text-body-md font-semibold text-secondary"><span>{c.cta}</span><Icon name="ArrowRight" size={18} className="transition-transform group-hover:translate-x-1" /></span>
    </Link>
  )
}

export function FaqList({ faqs }) {
  return (
    <div className="flex flex-col gap-space-sm">
      {faqs.map(([q, a]) => (
        <details key={q} className="group p-space-md lg:p-space-lg rounded-xl bg-surface-container-lowest shadow-sm transition-all [&_summary::-webkit-details-marker]:hidden">
          <summary className="flex items-center justify-between cursor-pointer list-none">
            <h3 className="font-headline-sm text-headline-sm font-bold text-on-surface pr-4">{q}</h3>
            <Icon name="ChevronDown" className="text-on-surface-variant transition-transform group-open:rotate-180 shrink-0" />
          </summary>
          <div className="pt-space-md mt-space-sm font-body-md text-body-md text-on-surface-variant leading-relaxed">{a}</div>
        </details>
      ))}
    </div>
  )
}

export const Eyebrow = ({ children, center }) => <span className={'font-label-badge text-label-badge text-secondary uppercase tracking-wider font-semibold ' + (center ? '' : '')}>{children}</span>

const STEPS = [
  ['01', 'Introduce los datos de tu coche', 'Selecciona el tipo de propulsión, consumos oficiales y tarifas habituales que pagas por el litro o el kilovatio hora.', 'SlidersHorizontal', 'Personalizable al 100%'],
  ['02', 'Indica cuánto utilizas el coche', 'Define tus kilómetros mensuales aproximados y los gastos fijos como seguro, impuestos municipales e ITV.', 'Route', 'Ajuste por uso real'],
  ['03', 'Obtén la estimación del coste real', 'Visualiza tu gasto mensual, coste por kilómetro y proyecciones a varios años con un desglose porcentual claro.', 'TrendingUp', 'Resultados instantáneos'],
]
export function HowItWorks({ h = 'h2', banner = true }) {
  const H = h
  return (
    <section className="w-full py-space-xl bg-surface-container-low">
      <div className="max-w-[1200px] mx-auto px-margin">
        <div className="text-center max-w-2xl mx-auto mb-space-xl">
          <Eyebrow>Proceso Transparente</Eyebrow>
          <H className="font-headline-lg text-headline-lg text-on-surface font-bold mt-1">Cómo funciona</H>
          <p className="font-body-lg text-body-lg text-on-surface-variant mt-2">En menos de un minuto obtendrás la radiografía financiera exacta de tu vehículo con total objetividad.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-gutter">
          {STEPS.map(([n, t, d, ic, tag], i) => (
            <div key={n} className="flex flex-col p-space-lg rounded-2xl bg-surface-container-lowest shadow-sm">
              <div className={'font-headline-metric text-headline-metric font-extrabold mb-space-sm ' + (i === 2 ? 'text-secondary/30' : 'text-surface-tint/20')}>{n}</div>
              <h3 className="font-headline-sm text-headline-sm font-bold text-on-surface mb-space-xs">{t}</h3>
              <p className="font-body-md text-body-md text-on-surface-variant">{d}</p>
              <div className="mt-space-md pt-space-md flex items-center gap-space-xs text-secondary font-body-sm text-body-sm"><Icon name={ic} size={16} /><span>{tag}</span></div>
            </div>
          ))}
        </div>
        {banner && (
          <div className="mt-space-xl p-space-lg rounded-2xl bg-surface-container-lowest shadow-sm flex flex-col md:flex-row items-center justify-between gap-space-lg">
            <div className="flex items-center gap-space-md">
              <div className="w-16 h-16 rounded-xl bg-primary-container text-secondary-fixed flex items-center justify-center shrink-0 shadow-sm"><Icon name="BarChart3" size={28} /></div>
              <div>
                <h4 className="font-headline-sm text-headline-sm font-bold text-on-surface">¿Por qué calcular el TCO (Total Cost of Ownership)?</h4>
                <p className="font-body-sm text-body-sm text-on-surface-variant">El precio del carburante representa menos del 45% del desembolso total de tener un vehículo en propiedad.</p>
              </div>
            </div>
            <Link to="/como-funciona#tco" className="px-space-md py-2.5 rounded-lg bg-surface-container text-on-surface font-body-md text-body-md font-semibold hover:bg-surface-container-high transition-colors whitespace-nowrap">Saber más sobre el TCO</Link>
          </div>
        )}
      </div>
    </section>
  )
}

const FACTORS = [
  ['Fuel', 'Variable', '1. Combustible o recarga', 'El gasto más recurrente y visible. Depende directamente del precio del carburante por litro o del kWh contratado, así como de la eficiencia del motor en ciclo mixto homologado WLTP.', '~35% a 45% del total'],
  ['Shield', 'Fijo obligatorio', '2. Seguro del vehículo', 'Póliza a terceros básica, ampliada o a todo riesgo. Un coste fijo anual obligatorio en España que condiciona el desembolso mensual independientemente de cuántos kilómetros conduzcas.', '~300 € a 900 € / año'],
  ['Wrench', 'Mantenimiento', '3. Taller y revisiones', 'Mantenimiento preventivo oficial: cambios de aceite, filtros de aire/polen, pastillas y discos de freno, líquido refrigerante y provisión ante averías mecánicas imprevistas.', '~250 € a 600 € / año'],
  ['Receipt', 'Tributario', '4. Impuestos (IVTM)', 'Impuesto sobre Vehículos de Tracción Mecánica fijado por cada ayuntamiento según los caballos fiscales (CVF) o potencia neta del propulsor.', '~60 € a 250 € / año'],
  ['CircleCheck', 'Inspección', '5. Inspección ITV', 'Trámite obligatorio para garantizar la seguridad activa y el control de emisiones. Exento en los primeros 4 años de vida del coche, bienal hasta los 10 y anual a partir de entonces.', '~35 € a 60 € por pase'],
  ['Disc', 'Seguridad', '6. Neumáticos', 'Sustitución recomendada cada 40.000 - 50.000 km o 5 años. Incluye el coste de montaje, equilibrado, paralelo y reciclaje NFU obligatorio.', '~0,01 € a 0,02 € / km'],
  ['TrendingDown', 'Coste oculto', '7. Depreciación', 'La devaluación del vehículo en el mercado de segunda mano. Un coche nuevo pierde hasta un 20% de su valor el primer año y un 10% adicional en los ejercicios sucesivos.', 'Mayor coste patrimonial'],
  ['ParkingSquare', 'Auxiliares', '8. Parkings, peajes y lavado', 'Gastos urbanos y de uso: alquiler de plaza de garaje, estacionamiento regulado (SER/zona azul), peajes en autopistas, limpieza regular y consumibles menores como limpiaparabrisas.', '~20 € a 120 € / mes'],
]
export function CostFactors() {
  return (
    <section id="seo-content" className="w-full py-space-xl lg:py-24 bg-surface scroll-mt-16">
      <div className="max-w-[1200px] mx-auto px-margin">
        <div className="max-w-3xl mb-space-xl">
          <Eyebrow>Guía Financiera</Eyebrow>
          <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold mt-1">¿Qué incluye el coste real de un coche?</h2>
          <p className="font-body-lg text-body-lg text-on-surface-variant mt-space-sm leading-relaxed">La mayoría de conductores únicamente contabilizan lo que gastan en repostar o recargar. Sin embargo, el <strong className="text-on-surface font-semibold">Coste Total de Propiedad (TCO)</strong> abarca partidas recurrentes y depreciación patrimonial que multiplican el gasto real. Analizamos los 8 factores determinantes:</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-gutter">
          {FACTORS.map(([ic, tag, t, d, r]) => (
            <article key={t} className="p-space-lg rounded-2xl bg-surface-container-lowest shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-space-xs mb-space-sm">
                  <span className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-on-surface"><Icon name={ic} size={18} /></span>
                  <span className="font-label-badge text-label-badge text-on-surface-variant uppercase">{tag}</span>
                </div>
                <h3 className="font-headline-sm text-headline-sm font-bold text-on-surface mb-2">{t}</h3>
                <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">{d}</p>
              </div>
              <div className="mt-space-md pt-space-xs font-body-sm text-body-sm text-secondary font-semibold">{r}</div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

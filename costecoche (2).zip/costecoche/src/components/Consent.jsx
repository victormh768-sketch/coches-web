import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ADSENSE } from '../data/site'

const KEY = 'cc_consent'
export const getConsent = () => { try { return localStorage.getItem(KEY) } catch { return null } }
export function loadAdsense() {
  if (!ADSENSE || document.querySelector('script[data-adsense]')) return
  const s = document.createElement('script'); s.async = true; s.dataset.adsense = '1'; s.crossOrigin = 'anonymous'
  s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + ADSENSE
  document.head.appendChild(s)
}
export function CookieBanner() {
  const [c, setC] = useState(getConsent())
  useEffect(() => { if (c === 'all') loadAdsense() }, [c])
  const set = (v) => { try { localStorage.setItem(KEY, v) } catch {} setC(v) }
  if (c) return null
  return (
    <div role="dialog" aria-label="Aviso de cookies" className="fixed bottom-4 left-4 right-4 md:left-auto md:max-w-md z-[60] p-space-md rounded-2xl bg-surface-container-lowest border border-outline-variant shadow-xl">
      <p className="font-body-sm text-body-sm text-on-surface-variant">Usamos cookies técnicas y, si lo aceptas, cookies publicitarias de Google AdSense. Más información en la <Link to="/politica-cookies" className="text-secondary font-semibold hover:underline">política de cookies</Link>.</p>
      <div className="flex gap-space-sm mt-space-sm">
        <button onClick={() => set('all')} className="flex-1 px-space-md py-2 rounded-lg bg-tertiary-container text-on-tertiary font-body-md text-body-md font-semibold">Aceptar</button>
        <button onClick={() => set('necessary')} className="flex-1 px-space-md py-2 rounded-lg bg-surface-container text-on-surface font-body-md text-body-md font-semibold">Solo necesarias</button>
      </div>
    </div>
  )
}
export function AdSlot({ slot, className = '' }) {
  useEffect(() => { if (ADSENSE && slot && getConsent() === 'all') { try { (window.adsbygoogle = window.adsbygoogle || []).push({}) } catch {} } }, [slot])
  if (!ADSENSE || !slot) return null
  return <ins className={'adsbygoogle block min-h-[100px] ' + className} data-ad-client={ADSENSE} data-ad-slot={slot} data-ad-format="auto" data-full-width-responsive="true" />
}

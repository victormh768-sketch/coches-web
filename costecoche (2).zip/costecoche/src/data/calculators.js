// Para añadir una calculadora: añade un objeto a CALCULATORS (y su ruta se genera sola).
import { eur, num, val } from '../lib/format'

const fuel = (km, c, p) => (km * c / 100) * p
const F = (id, label, def, step = 1, unit = '') => ({ id, label, def, step, unit })

export const MAIN = {
  path: '/calculadora-coste-coche', title: 'Calculadora de coste del coche', icon: 'Calculator',
  cardDesc: 'Suma combustible, seguro, mantenimiento e impuestos y obtén tu coste mensual, anual y por kilómetro.', cta: 'Calcular coste total',
  seo: { title: 'Calculadora de coste del coche: cuánto cuesta realmente | CosteCoche', description: 'Calcula gratis el coste real de tu coche: combustible, seguro, mantenimiento, impuestos e ITV. Resultado mensual, anual y por kilómetro.' },
  h1: 'Calculadora de coste del coche',
  faqs: [['¿Qué incluye el cálculo?', 'Combustible o electricidad, seguro, mantenimiento, impuesto de circulación (IVTM), ITV y otros gastos fijos anuales. No incluye la compra ni la depreciación.'], ['¿Se guardan mis datos?', 'No. Todos los cálculos se hacen en tu navegador y no enviamos nada a ningún servidor.']],
}

export const CALCULATORS = [
  {
    path: '/coste-por-kilometro', title: 'Coste por kilómetro', icon: 'Gauge',
    cardDesc: 'Descubre exactamente cuánto te cuesta cada kilómetro recorrido teniendo en cuenta neumáticos y depreciación.', cta: 'Calcular coste por km',
    seo: { title: 'Calculadora de coste por kilómetro del coche | CosteCoche', description: 'Calcula cuánto te cuesta cada kilómetro con tu coche: combustible, seguro, mantenimiento, neumáticos y depreciación.' },
    h1: 'Calculadora de coste por kilómetro',
    intro: 'El coste por kilómetro reparte todos los gastos del coche entre los kilómetros que haces. Sirve para comparar con el transporte público, negociar kilometraje o saber cuánto reclamar por un desplazamiento.',
    sections: [{ fields: [F('km', 'Kilómetros al año', 15000, 500, 'km'), F('c', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('p', 'Precio del combustible (€/l)', 1.62, 0.01, '€'), F('seg', 'Seguro anual', 480, 10, '€'), F('mant', 'Mantenimiento anual', 350, 10, '€'), F('imp', 'Impuestos (IVTM) anual', 140, 5, '€'), F('neu', 'Neumáticos (€/km)', 0.015, 0.005, '€'), F('dep', 'Depreciación anual', 1500, 100, '€')] }],
    compute(v) {
      const km = val(v.km), comb = fuel(km, val(v.c), val(v.p)), neu = km * val(v.neu)
      const fijos = val(v.seg) + val(v.imp), mant = val(v.mant) + neu, dep = val(v.dep)
      const tot = comb + fijos + mant + dep, pk = (x) => (km ? x / km : 0)
      return { headline: { label: 'Tu coche te cuesta', value: num(pk(tot), 2), unit: '€ / km', sub: 'Incluye depreciación, combustible, seguro, impuestos y mantenimiento.' }, badge: eur(tot) + ' / año',
        cards: [['Solo combustible', eur(pk(comb), 2)], ['Sin depreciación', eur(pk(tot - dep), 2)], ['Total anual', eur(tot)]],
        breakdown: [['Combustible', comb], ['Seguro e impuestos', fijos], ['Taller y neumáticos', mant], ['Depreciación', dep]], note: 'Estimación con los datos introducidos.' }
    },
    faqs: [['¿Cuál es un buen coste por kilómetro?', 'Para un coche urbano de gasolina suele estar entre 0,25 € y 0,40 € por km si se incluye la depreciación. Baja cuanto más kilómetros haces.'], ['¿Por qué importa la depreciación?', 'Es el gasto que menos se ve: el valor que pierde tu coche cada año en el mercado de segunda mano.']],
  },
  {
    path: '/coste-viaje', title: 'Coste de un viaje', icon: 'Navigation',
    cardDesc: 'Calcula con precisión cuánto gastarás en combustible, peajes y desgaste para cualquier trayecto o vacaciones.', cta: 'Planificar viaje',
    seo: { title: 'Calculadora de coste de un viaje en coche | CosteCoche', description: 'Calcula el coste de un viaje en coche: combustible, peajes y desgaste, total y por persona. Ideal para repartir gastos.' },
    h1: 'Calculadora de coste de un viaje en coche',
    intro: 'Indica la distancia, el consumo y los peajes para saber cuánto costará el trayecto y cuánto toca pagar a cada ocupante si repartís gastos.',
    sections: [{ fields: [F('d', 'Distancia de un trayecto (km)', 400, 10, 'km'), F('t', 'Trayectos (1 = ida, 2 = ida y vuelta)', 2, 1), F('c', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('p', 'Precio del combustible (€/l)', 1.62, 0.01, '€'), F('peaje', 'Peajes totales', 25, 1, '€'), F('otros', 'Parking y otros', 10, 1, '€'), F('des', 'Desgaste (€/km)', 0.03, 0.005, '€'), F('oc', 'Ocupantes', 2, 1)] }],
    compute(v) {
      const km = val(v.d) * Math.max(1, val(v.t)), litros = km * val(v.c) / 100, comb = litros * val(v.p), des = km * val(v.des)
      const peaje = val(v.peaje), otros = val(v.otros), tot = comb + des + peaje + otros
      return { headline: { label: 'Coste total del viaje', value: num(tot), unit: '€', sub: km + ' km en total.' }, badge: eur(tot / Math.max(1, val(v.oc))) + ' por persona',
        cards: [['Por persona', eur(tot / Math.max(1, val(v.oc)))], ['Combustible', num(litros, 1) + ' l'], ['Por km', eur(km ? tot / km : 0, 2)]],
        breakdown: [['Combustible', comb], ['Peajes', peaje], ['Desgaste', des], ['Parking y otros', otros]], note: 'El desgaste incluye neumáticos, frenos y mantenimiento proporcional.' }
    },
    faqs: [['¿Cómo reparto los gastos entre ocupantes?', 'Divide el total entre todas las personas, conductor incluido. Con el resultado "por persona" ya lo tienes.'], ['¿Debo contar el desgaste?', 'Es opcional, pero un viaje largo consume neumáticos y frenos. Con 0,03 €/km tienes una estimación razonable.']],
  },
  {
    path: '/coste-mensual', title: 'Coste mensual del coche', icon: 'CalendarDays',
    cardDesc: 'Averigua cuánto impacta el coche en tus finanzas mensuales, incluyendo amortización de cuota y seguro prorrateado.', cta: 'Calcular presupuesto mensual',
    seo: { title: 'Calculadora de coste mensual del coche | CosteCoche', description: 'Calcula cuánto te cuesta tener coche cada mes: cuota, combustible, seguro prorrateado, mantenimiento, impuestos y parking.' },
    h1: 'Calculadora de coste mensual del coche',
    intro: 'Convierte los gastos anuales en una cifra mensual para saber cuánto pesa el coche en tu presupuesto.',
    sections: [{ fields: [F('km', 'Kilómetros al mes', 1250, 50, 'km'), F('c', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('p', 'Precio del combustible (€/l)', 1.62, 0.01, '€'), F('cuota', 'Cuota de financiación al mes', 0, 10, '€'), F('park', 'Parking / garaje al mes', 0, 5, '€'), F('seg', 'Seguro anual', 480, 10, '€'), F('mant', 'Mantenimiento anual', 350, 10, '€'), F('imp', 'Impuestos (IVTM) anual', 140, 5, '€'), F('itv', 'ITV y otros anual', 60, 5, '€')] }],
    compute(v) {
      const km = val(v.km), comb = fuel(km, val(v.c), val(v.p)), cuota = val(v.cuota) + val(v.park)
      const segImp = (val(v.seg) + val(v.imp)) / 12, mant = (val(v.mant) + val(v.itv)) / 12, tot = comb + cuota + segImp + mant
      return { headline: { label: 'Tu coche te cuesta', value: num(tot), unit: '€ / mes', sub: 'Suma de energía, cuota, seguros, tasas y mantenimiento.' }, badge: eur(tot * 12) + ' / año',
        cards: [['Por km', eur(km ? tot / km : 0, 2)], ['Al día', eur(tot / 30.4, 2)], ['Al año', eur(tot * 12)]],
        breakdown: [['Combustible', comb], ['Cuota y parking', cuota], ['Seguro e impuestos', segImp], ['Taller e ITV', mant]], note: 'Si el coche está pagado, deja la cuota a 0.' }
    },
    faqs: [['¿Cómo prorrateo el seguro?', 'Divide la prima anual entre 12. La calculadora lo hace por ti.'], ['¿Qué porcentaje de mi sueldo debería costar el coche?', 'Muchos planificadores financieros recomiendan no superar el 15 % de los ingresos netos mensuales.']],
  },
  {
    path: '/coste-anual', title: 'Coste anual', icon: 'LineChart',
    cardDesc: 'Descubre el coste total de mantener tu coche durante un año y compara con modalidades como renting o suscripción.', cta: 'Auditar coste anual',
    seo: { title: 'Calculadora de coste anual del coche con depreciación | CosteCoche', description: 'Calcula el coste anual de tu coche incluyendo depreciación, combustible, seguro, impuestos, ITV y parking. Proyección a 5 años.' },
    h1: 'Calculadora de coste anual del coche',
    intro: 'El coste anual incluye lo que pagas y lo que pierdes: además de los gastos habituales, calcula la depreciación de tu vehículo.',
    sections: [{ fields: [F('km', 'Kilómetros al año', 15000, 500, 'km'), F('c', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('p', 'Precio del combustible (€/l)', 1.62, 0.01, '€'), F('seg', 'Seguro anual', 480, 10, '€'), F('mant', 'Mantenimiento anual', 350, 10, '€'), F('imp', 'Impuestos (IVTM) anual', 140, 5, '€'), F('itv', 'ITV y otros anual', 60, 5, '€'), F('park', 'Parking / garaje al mes', 30, 5, '€'), F('valor', 'Valor actual del coche', 18000, 500, '€'), F('depp', 'Depreciación anual (%)', 10, 1, '%')] }],
    compute(v) {
      const km = val(v.km), comb = fuel(km, val(v.c), val(v.p)), segImp = val(v.seg) + val(v.imp)
      const taller = val(v.mant) + val(v.itv) + val(v.park) * 12, dep = val(v.valor) * val(v.depp) / 100, tot = comb + segImp + taller + dep
      return { headline: { label: 'Coste anual del coche', value: num(tot), unit: '€ / año', sub: 'Incluye la pérdida de valor del vehículo.' }, badge: eur(tot / 12) + ' / mes',
        cards: [['Al mes', eur(tot / 12)], ['Por km', eur(km ? tot / km : 0, 2)], ['En 5 años', eur(tot * 5)]],
        breakdown: [['Combustible', comb], ['Seguro e impuestos', segImp], ['Taller, ITV y parking', taller], ['Depreciación', dep]], note: 'La proyección a 5 años asume costes constantes.' }
    },
    faqs: [['¿Cuánto se deprecia un coche al año?', 'De media entre un 10 % y un 15 % anual; más el primer año en un coche nuevo.'], ['¿Cómo comparo con renting?', 'Suma la cuota anual del renting (suele incluir seguro y mantenimiento) y compárala con este total.']],
  },
  {
    path: '/coche-electrico', title: 'Coche eléctrico', icon: 'PlugZap',
    cardDesc: 'Calcula con precisión cuánto cuesta cargar en casa (tarifa valle), en cargadores rápidos públicos y el ahorro en mantenimiento.', cta: 'Simular recargas EV',
    seo: { title: 'Calculadora de coste de un coche eléctrico y recarga | CosteCoche', description: 'Calcula cuánto cuesta recargar un coche eléctrico en casa y en cargadores públicos y cuánto ahorras frente a la gasolina.' },
    h1: 'Calculadora de coste de un coche eléctrico',
    intro: 'Combina recarga doméstica y pública para estimar el gasto energético de tu eléctrico y compáralo con un coche de gasolina equivalente.',
    sections: [{ title: 'Coche eléctrico', fields: [F('km', 'Kilómetros al mes', 1250, 50, 'km'), F('kwh', 'Consumo (kWh/100 km)', 17.5, 0.1, 'kWh'), F('casa', 'Recarga en casa (%)', 80, 5, '%'), F('pc', 'Precio en casa (€/kWh)', 0.15, 0.01, '€'), F('pp', 'Precio en público (€/kWh)', 0.45, 0.01, '€'), F('mev', 'Mantenimiento anual EV', 200, 10, '€')] }, { title: 'Gasolina equivalente', fields: [F('cg', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('pg', 'Precio gasolina (€/l)', 1.62, 0.01, '€'), F('mg', 'Mantenimiento anual', 350, 10, '€')] }],
    compute(v) {
      const kwh = val(v.km) * val(v.kwh) / 100, h = Math.min(100, val(v.casa)) / 100
      const casa = kwh * h * val(v.pc), pub = kwh * (1 - h) * val(v.pp), mev = val(v.mev), ev = (casa + pub) * 12 + mev
      const gas = fuel(val(v.km), val(v.cg), val(v.pg)) * 12 + val(v.mg), ah = gas - ev
      return { headline: { label: 'Energía de tu eléctrico', value: num(casa + pub, 1), unit: '€ / mes', sub: num(kwh) + ' kWh al mes.' }, badge: (ah >= 0 ? 'Ahorras ' : 'Pagas ') + eur(Math.abs(ah)) + ' / año',
        cards: [['EV al año', eur(ev)], ['Gasolina al año', eur(gas)], [ah >= 0 ? 'Ahorro anual' : 'Sobrecoste', eur(Math.abs(ah))]],
        breakdown: [['Recarga en casa', casa * 12], ['Recarga pública', pub * 12], ['Mantenimiento', mev]], note: 'Comparación de gasto de uso; no incluye el precio de compra.' }
    },
    faqs: [['¿Cuánto cuesta recargar en casa?', 'Con tarifa valle suele rondar 0,08–0,15 €/kWh, frente a 0,35–0,60 €/kWh en carga rápida pública.'], ['¿Por qué el mantenimiento es menor?', 'No hay aceite, embrague ni correas de distribución, y el frenado regenerativo alarga la vida de los frenos.']],
  },
  {
    path: '/comparador', title: 'Gasolina vs eléctrico', icon: 'Scale',
    cardDesc: 'Compara dos modelos cara a cara: averigua el punto de equilibrio para compensar el sobrecoste del vehículo eléctrico.', cta: 'Comparar tecnologías',
    seo: { title: 'Comparador de costes: gasolina vs eléctrico | CosteCoche', description: 'Compara el coste total de un coche de gasolina y uno eléctrico a varios años y calcula cuándo se amortiza la diferencia de precio.' },
    h1: 'Comparador de costes: gasolina vs eléctrico',
    intro: 'Introduce los datos de ambos coches y descubre cuál sale más barato a lo largo de los años y cuándo se amortiza el sobreprecio.',
    sections: [{ title: 'Gasolina', fields: [F('pa', 'Precio de compra', 22000, 500, '€'), F('ca', 'Consumo (l/100 km)', 6.5, 0.1, 'l'), F('ea', 'Precio (€/l)', 1.62, 0.01, '€'), F('sa', 'Seguro anual', 480, 10, '€'), F('ma', 'Mantenimiento anual', 350, 10, '€'), F('ia', 'Impuestos anual', 140, 5, '€')] }, { title: 'Eléctrico', fields: [F('pb', 'Precio de compra', 32000, 500, '€'), F('cb', 'Consumo (kWh/100 km)', 17.5, 0.1, 'kWh'), F('eb', 'Precio medio (€/kWh)', 0.22, 0.01, '€'), F('sb', 'Seguro anual', 560, 10, '€'), F('mb', 'Mantenimiento anual', 200, 10, '€'), F('ib', 'Impuestos anual', 40, 5, '€')] }, { title: 'Uso', fields: [F('km', 'Kilómetros al año', 15000, 500, 'km'), F('y', 'Años de tenencia', 5, 1), F('res', 'Valor de reventa (%)', 40, 5, '%')] }],
    compute(v) {
      const km = val(v.km), y = Math.max(1, val(v.y)), keep = 1 - Math.min(100, val(v.res)) / 100
      const run = (c, e, s, m, i) => fuel(km, val(c), val(e)) + val(s) + val(m) + val(i)
      const ra = run(v.ca, v.ea, v.sa, v.ma, v.ia), rb = run(v.cb, v.eb, v.sb, v.mb, v.ib)
      const ta = val(v.pa) * keep + ra * y, tb = val(v.pb) * keep + rb * y, d = ta - tb
      const dif = val(v.pb) - val(v.pa), be = rb < ra ? dif / (ra - rb) : null
      return { headline: { label: d >= 0 ? 'Ahorro con el eléctrico' : 'Sobrecoste del eléctrico', value: num(Math.abs(d)), unit: '€ en ' + y + (y === 1 ? ' año' : ' años'), sub: 'Compra menos reventa más gastos de uso.' }, badge: be === null ? 'Sin punto de equilibrio' : be <= 0 ? 'Eléctrico más barato desde el inicio' : 'Equilibrio en ' + num(be, 1) + ' años',
        cards: [['Gasolina', eur(ta)], ['Eléctrico', eur(tb)], ['Uso anual', eur(ra - rb)]],
        breakdown: [['Compra neta gasolina', val(v.pa) * keep], ['Uso gasolina', ra * y], ['Compra neta EV', val(v.pb) * keep], ['Uso EV', rb * y]], note: '"Uso anual" es lo que ahorras cada año en gastos de uso con el eléctrico.' }
    },
    faqs: [['¿Cómo se calcula el punto de equilibrio?', 'Dividiendo la diferencia de precio de compra entre lo que ahorras cada año en gastos de uso.'], ['¿Qué precio medio del kWh uso?', 'Mezcla tu carga en casa y en público. Con un 80 % en casa, unos 0,20–0,25 €/kWh es realista.']],
  },
]
export const ALL = [MAIN, ...CALCULATORS]

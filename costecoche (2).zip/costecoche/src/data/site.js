export const SITE = import.meta.env.VITE_SITE_URL || 'https://costecoche.es'
export const NAME = 'CosteCoche'
export const CONTACT_EMAIL = 'contacto@costecoche.es' // TODO: cambiar por tu email real
export const ADSENSE = import.meta.env.VITE_ADSENSE_CLIENT || ''

import { useState } from 'react'
import Seo from '../components/Seo'
import { HowItWorks, CostFactors } from '../components/ui'
import { CONTACT_EMAIL } from '../data/site'

function Shell({ title, intro, children, seo }) {
  return (
    <>
      <Seo title={seo.title} description={seo.description} noindex={seo.noindex} />
      <section className="w-full bg-surface py-space-xl lg:py-24">
        <div className="max-w-[880px] mx-auto px-margin">
          <h1 className="font-display-hero-mobile md:font-display-hero text-display-hero-mobile md:text-display-hero text-on-surface font-extrabold tracking-tight">{title}</h1>
          {intro && <p className="font-body-lg text-body-lg text-on-surface-variant mt-space-md">{intro}</p>}
          <div className="mt-space-xl flex flex-col gap-space-lg">{children}</div>
        </div>
      </section>
    </>
  )
}
const Sec = ({ h, children }) => (
  <div><h2 className="font-headline-md text-headline-md text-on-surface font-semibold mb-space-sm">{h}</h2><div className="font-body-lg text-body-lg text-on-surface-variant flex flex-col gap-space-sm">{children}</div></div>
)
const upd = <p className="font-body-sm text-body-sm text-on-surface-variant">Última actualización: octubre de 2026.</p>

export function About() {
  return (
    <Shell seo={{ title: 'Sobre nosotros | CosteCoche', description: 'Quiénes somos y por qué creamos CosteCoche: calculadoras gratuitas e independientes del coste real del coche.' }} title="Sobre nosotros" intro="CosteCoche nace para que cualquier conductor pueda saber, sin registros ni letra pequeña, cuánto le cuesta de verdad su coche.">
      <Sec h="Nuestra misión"><p>Casi nadie suma todos los gastos de su vehículo. Ofrecemos calculadoras claras y gratuitas basadas en el Coste Total de Propiedad (TCO) para decidir con datos: comprar, mantener, cambiar a eléctrico o planificar un viaje.</p></Sec>
      <Sec h="Independencia"><p>No vendemos coches, seguros ni financiación. Los cálculos se ejecutan en tu navegador y no almacenamos los datos que introduces.</p></Sec>
      <Sec h="Cómo nos financiamos"><p>Podemos mostrar publicidad contextual de terceros (Google AdSense) para mantener el sitio gratuito. La publicidad nunca altera los resultados.</p></Sec>
    </Shell>
  )
}
export function HowPage() {
  return (
    <>
      <Seo title="Cómo funciona CosteCoche y qué es el TCO" description="Aprende cómo calculamos el coste real de tu coche con la metodología TCO y qué gastos se incluyen: combustible, seguro, impuestos, ITV, mantenimiento y depreciación." />
      <section className="bg-surface pt-space-xl lg:pt-24"><div className="max-w-[1200px] mx-auto px-margin"><h1 className="font-display-hero-mobile md:font-display-hero text-display-hero-mobile md:text-display-hero text-on-surface font-extrabold tracking-tight">Cómo funciona CosteCoche</h1></div></section>
      <HowItWorks banner={false} h="h2" />
      <div id="tco" className="scroll-mt-16"><CostFactors /></div>
    </>
  )
}
export function Contact() {
  const [f, setF] = useState({ n: '', e: '', m: '' })
  const go = (e) => { e.preventDefault(); window.location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent('Contacto CosteCoche')}&body=${encodeURIComponent(f.m + '\n\n' + f.n + ' <' + f.e + '>')}` }
  const cls = 'w-full bg-surface-container-low rounded-lg px-space-md py-2.5 font-body-md text-body-md text-on-surface focus:outline-none focus:ring-2 focus:ring-secondary'
  return (
    <Shell seo={{ title: 'Contacto | CosteCoche', description: 'Contacta con CosteCoche para sugerencias, errores en los cálculos o propuestas de colaboración.' }} title="Contacto" intro="¿Has encontrado un error o quieres sugerir una calculadora? Escríbenos.">
      <form onSubmit={go} className="p-space-lg rounded-2xl bg-surface-container-lowest shadow-sm flex flex-col gap-space-md">
        <label className="flex flex-col gap-space-xs font-body-md font-semibold">Nombre<input required className={cls} value={f.n} onChange={(e) => setF({ ...f, n: e.target.value })} /></label>
        <label className="flex flex-col gap-space-xs font-body-md font-semibold">Email<input required type="email" className={cls} value={f.e} onChange={(e) => setF({ ...f, e: e.target.value })} /></label>
        <label className="flex flex-col gap-space-xs font-body-md font-semibold">Mensaje<textarea required rows="5" className={cls} value={f.m} onChange={(e) => setF({ ...f, m: e.target.value })} /></label>
        <button className="self-start px-space-lg py-2.5 rounded-lg bg-tertiary-container text-on-tertiary font-body-md font-semibold hover:bg-on-tertiary-fixed-variant transition-colors">Enviar mensaje</button>
        <p className="font-body-sm text-body-sm text-on-surface-variant">Se abrirá tu aplicación de correo. También puedes escribir a <a className="text-secondary font-semibold" href={'mailto:' + CONTACT_EMAIL}>{CONTACT_EMAIL}</a>.</p>
      </form>
    </Shell>
  )
}
export function Privacy() {
  return (
    <Shell seo={{ title: 'Política de privacidad | CosteCoche', description: 'Cómo tratamos tus datos en CosteCoche conforme al RGPD y la LOPDGDD.' }} title="Política de privacidad" intro="Resumen: los cálculos se hacen en tu navegador y no recogemos los datos que introduces.">
      {upd}
      <Sec h="Responsable"><p>[Nombre o razón social], NIF [NIF], domicilio [dirección], email {CONTACT_EMAIL}. (Completa estos datos antes de publicar.)</p></Sec>
      <Sec h="Datos que tratamos"><p>Los valores de las calculadoras no salen de tu dispositivo. Si nos escribes, tratamos tu nombre, email y mensaje para responderte (base jurídica: tu consentimiento) y los conservamos el tiempo necesario para atender la consulta.</p></Sec>
      <Sec h="Terceros"><p>Con tu consentimiento, Google AdSense puede usar cookies para mostrar anuncios personalizados. Google actúa como responsable independiente según su <a className="text-secondary font-semibold" href="https://policies.google.com/privacy" rel="noopener noreferrer">política de privacidad</a>.</p></Sec>
      <Sec h="Tus derechos"><p>Puedes ejercer acceso, rectificación, supresión, oposición, limitación y portabilidad escribiendo a {CONTACT_EMAIL}. Si no estás conforme, puedes reclamar ante la Agencia Española de Protección de Datos (aepd.es).</p></Sec>
    </Shell>
  )
}
export function Cookies() {
  const reset = () => { try { localStorage.removeItem('cc_consent') } catch {} window.location.reload() }
  return (
    <Shell seo={{ title: 'Política de cookies | CosteCoche', description: 'Qué cookies usa CosteCoche y cómo puedes gestionarlas.' }} title="Política de cookies" intro="Usamos un almacenamiento técnico mínimo y, solo si lo aceptas, cookies publicitarias.">
      {upd}
      <Sec h="Técnicas (necesarias)"><p>Guardamos en tu navegador (localStorage) únicamente tu elección sobre cookies. No requieren consentimiento.</p></Sec>
      <Sec h="Publicitarias (con consentimiento)"><p>Google AdSense puede instalar cookies propias y de terceros para mostrar y medir anuncios. No se cargan hasta que pulsas "Aceptar".</p></Sec>
      <Sec h="Gestionar tu elección"><p>Puedes cambiar tu decisión en cualquier momento y borrar las cookies desde la configuración de tu navegador.</p><button onClick={reset} className="self-start px-space-md py-2 rounded-lg bg-surface-container text-on-surface font-body-md font-semibold hover:bg-surface-container-high">Cambiar mi elección</button></Sec>
    </Shell>
  )
}
export function Terms() {
  return (
    <Shell seo={{ title: 'Términos y condiciones | CosteCoche', description: 'Condiciones de uso de CosteCoche y aviso legal.' }} title="Términos y condiciones" intro="Al usar CosteCoche aceptas estas condiciones.">
      {upd}
      <Sec h="Uso del servicio"><p>Las calculadoras son gratuitas y para uso personal e informativo.</p></Sec>
      <Sec h="Sin asesoramiento"><p>Los resultados son estimaciones orientativas y no constituyen asesoramiento financiero, fiscal ni legal. No nos responsabilizamos de decisiones tomadas a partir de ellos.</p></Sec>
      <Sec h="Propiedad intelectual"><p>El diseño, los textos y el código del sitio pertenecen a su titular. Queda prohibida su reproducción sin autorización.</p></Sec>
      <Sec h="Legislación"><p>Estas condiciones se rigen por la legislación española.</p></Sec>
    </Shell>
  )
}

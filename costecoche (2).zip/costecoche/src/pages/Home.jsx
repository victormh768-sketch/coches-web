import { Link } from 'react-router-dom'
import Seo, { faqLd } from '../components/Seo'
import Icon from '../components/Icon'
import MainCalculator from '../components/MainCalculator'
import { ToolCard, HowItWorks, CostFactors, FaqList, Eyebrow } from '../components/ui'
import { AdSlot } from '../components/Consent'
import { CALCULATORS } from '../data/calculators'
import { SITE } from '../data/site'

const FAQS = [
  ['¿Cómo se calcula el coste por kilómetro?', 'Se calcula dividiendo la suma total de gastos fijos (seguro, impuestos, mantenimiento anual) y gastos variables (combustible y desgaste) entre los kilómetros totales recorridos en el periodo analizado. Cuantos más kilómetros hagas al año, menor suele ser el coste por kilómetro debido a la amortización de los costes fijos.'],
  ['¿Qué gastos debo incluir para un cálculo riguroso?', 'Para un cálculo exhaustivo debes incluir combustible o electricidad, póliza de seguro anual, revisiones preventivas oficiales, cuota de amortización o financiación, IVTM, inspección periódica de ITV, cambio de neumáticos y la depreciación estimada del vehículo.'],
  ['¿Puedo calcular el coste de un coche eléctrico?', 'Sí, disponemos de parámetros específicos para vehículos 100% eléctricos (BEV) que tienen en cuenta el coste por kWh según tarifas domésticas (horas valle) o recargas públicas en carretera, así como el menor coste de mantenimiento mecánico por ausencia de aceite, embrague o correas.'],
  ['¿Puedo comparar dos coches simultáneamente?', 'Nuestra herramienta "Gasolina vs Eléctrico" te permite enfrentar dos modelos cara a cara para comprobar en cuántos años se amortiza la diferencia de precio inicial mediante el ahorro en consumo.'],
  ['¿Los resultados de la calculadora son exactos?', 'Son estimaciones basadas en los datos que introduces y en fórmulas estándar de contabilidad TCO. Los resultados reales pueden variar según tu estilo de conducción y las tarifas que tengas contratadas.'],
  ['¿Cómo puedo reducir el coste mensual de mi coche?', 'Puedes reducir costes adoptando técnicas de conducción eficiente (ahorro de hasta un 15% de combustible), ajustando la franquicia del seguro según los años de tu coche, manteniendo la presión óptima de los neumáticos y concentrando recargas eléctricas en tramos nocturnos bonificados.'],
]

export default function Home() {
  return (
    <div className="flex flex-col w-full">
      <Seo title="CosteCoche: calculadoras gratis del coste real de tu coche" description="Calcula en segundos cuánto cuesta realmente tu coche: combustible, seguro, mantenimiento, impuestos y costes ocultos. Calculadoras gratuitas y sin registro."
        jsonLd={[faqLd(FAQS), { '@context': 'https://schema.org', '@type': 'WebSite', name: 'CosteCoche', url: SITE, inLanguage: 'es' }]} />
      <section className="relative w-full overflow-hidden bg-surface py-space-xl lg:py-24">
        <div className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-[720px] h-[360px] bg-secondary-fixed/30 rounded-full blur-3xl opacity-50" />
        <div className="pointer-events-none absolute top-48 -left-20 w-80 h-80 bg-surface-container-high rounded-full blur-2xl opacity-70" />
        <div className="relative max-w-[1200px] mx-auto px-margin">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-space-xs px-space-md py-1 rounded-full bg-surface-container-lowest shadow-sm mb-space-lg text-on-surface-variant font-label-badge text-label-badge">
              <span className="w-2 h-2 rounded-full bg-secondary animate-pulse" /><span>Actualizado {new Date().getFullYear()} · Tarifas medias y carburantes oficiales</span>
            </div>
            <h1 className="font-display-hero-mobile md:font-display-hero text-display-hero-mobile md:text-display-hero text-on-surface font-extrabold tracking-tight mb-space-md">¿Cuánto te cuesta <span className="text-secondary">realmente</span> tu coche?</h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant max-w-2xl mb-space-xl">Calcula en segundos cuánto gastas en combustible, seguro, mantenimiento, impuestos y costes ocultos con nuestra metodología TCO independiente.</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-space-md w-full sm:w-auto mb-space-xl">
              <a href="#calculadora-principal" className="w-full sm:w-auto inline-flex items-center justify-center gap-space-xs px-space-xl py-3.5 rounded-lg bg-tertiary-container text-on-tertiary font-headline-sm text-headline-sm font-semibold shadow-md hover:bg-on-tertiary-fixed-variant transition-all hover:-translate-y-0.5"><Icon name="Calculator" size={20} />Calcular ahora</a>
              <Link to="/calculadoras" className="w-full sm:w-auto inline-flex items-center justify-center gap-space-xs px-space-xl py-3.5 rounded-lg bg-surface-container-lowest text-on-surface font-headline-sm text-headline-sm font-semibold shadow-sm hover:bg-surface-container transition-all"><Icon name="LayoutGrid" size={20} />Ver calculadoras</Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-md w-full pt-space-md">
              {[['CheckCircle2', '100% Gratuito y sin registro'], ['RefreshCw', 'Precios y tarifas actualizados'], ['Landmark', 'Metodología financiera TCO neutral']].map(([i, t]) => (
                <div key={t} className="flex items-center justify-center gap-space-xs text-on-surface-variant font-body-sm text-body-sm"><Icon name={i} size={18} className="text-secondary" /><span>{t}</span></div>
              ))}
            </div>
          </div>
        </div>
      </section>
      <section id="calculadora-principal" className="w-full py-space-xl bg-surface-container-low scroll-mt-20 pb-24 lg:pb-space-xl">
        <div className="max-w-[1200px] mx-auto px-margin"><MainCalculator /></div>
      </section>
      <section id="herramientas" className="w-full py-space-xl lg:py-24 bg-surface scroll-mt-16">
        <div className="max-w-[1200px] mx-auto px-margin">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-xl">
            <div className="max-w-2xl">
              <div className="inline-flex items-center px-2.5 py-1 rounded-full bg-surface-container-high text-on-surface font-label-badge text-label-badge uppercase tracking-wider mb-space-xs">Ecosistema de Cálculo</div>
              <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold">¿Qué puedes calcular?</h2>
              <p className="font-body-lg text-body-lg text-on-surface-variant mt-1">Herramientas especializadas y gratuitas para cada necesidad financiera de tu vehículo.</p>
            </div>
            <div className="hidden md:flex items-center gap-space-xs text-on-surface-variant font-body-sm text-body-sm"><Icon name="ShieldCheck" size={18} className="text-secondary" />Algoritmos con fórmulas TCO estándar</div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-gutter">{CALCULATORS.map((c) => <ToolCard key={c.path} c={c} />)}</div>
        </div>
      </section>
      <HowItWorks />
      <CostFactors />
      <section className="w-full py-space-xl lg:py-24 bg-surface-container-low">
        <div className="max-w-[880px] mx-auto px-margin">
          <div className="text-center mb-space-xl">
            <Eyebrow>Respuestas Inmediatas</Eyebrow>
            <h2 className="font-headline-lg text-headline-lg text-on-surface font-bold mt-1">Preguntas frecuentes sobre el coste del coche</h2>
            <p className="font-body-lg text-body-lg text-on-surface-variant mt-2">Resolvemos las dudas más comunes sobre el cálculo financiero de propiedad y gastos de tu automóvil.</p>
          </div>
          <FaqList faqs={FAQS} />
          <AdSlot slot={import.meta.env.VITE_ADSENSE_SLOT_HOME} className="mt-space-xl" />
        </div>
      </section>
    </div>
  )
}

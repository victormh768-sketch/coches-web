import Seo from '../components/Seo'
import { ToolCard } from '../components/ui'
import { ALL } from '../data/calculators'

export default function Calculadoras() {
  return (
    <>
      <Seo title="Todas las calculadoras del coche | CosteCoche" description="Calculadoras gratuitas: coste por kilómetro, coste de un viaje, coste mensual y anual, coche eléctrico y comparador gasolina vs eléctrico." />
      <section className="w-full bg-surface py-space-xl lg:py-24">
        <div className="max-w-[1200px] mx-auto px-margin">
          <div className="max-w-2xl mb-space-xl">
            <h1 className="font-display-hero-mobile md:font-display-hero text-display-hero-mobile md:text-display-hero text-on-surface font-extrabold tracking-tight">Todas las calculadoras</h1>
            <p className="font-body-lg text-body-lg text-on-surface-variant mt-space-md">Herramientas especializadas y gratuitas para cada necesidad financiera de tu vehículo. Sin registro y sin enviar tus datos a ningún servidor.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-gutter">{ALL.map((c) => <ToolCard key={c.path} c={c} />)}</div>
        </div>
      </section>
    </>
  )
}
